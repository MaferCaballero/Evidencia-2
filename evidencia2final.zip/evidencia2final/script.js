// jQuery example to scroll to 'About Us' section
$(document).ready(function(){
    $('.btn').click(function() {
        $('html, body').animate({
            scrollTop: $('#about').offset().top
        }, 1000);
    });
});
const menuToggle = document.getElementById('menuToggle');
const navMenu = document.getElementById('navMenu');

menuToggle.addEventListener('click', () => {
  navMenu.classList.toggle('active');
  menuToggle.classList.toggle('open');
});
